document.querySelector('h1').addEventListener('animationend', () => {
  console.log('Animasi judul selesai!');
});